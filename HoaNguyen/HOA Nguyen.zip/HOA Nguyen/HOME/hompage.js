


$(function(){
    $(".dropdown-item1").click(function(){
        var seleted_text1 =$(this).html();
        $(".dropdown-toggle1").html(seleted_text1)
    })
})
$(function(){
    $(".dropdown-item2").click(function(){
        var seleted_text2 =$(this).html();
        $(".dropdown-toggle2").html(seleted_text2)
    })
})

$(function(){
    $("[data-trigger]").on("click",function(){
        var targeet_id =$(this).attr('data-trigger');
        $(targeet_id).toggleClass("show");
        $('body').toggleClass("offcanvas-active");
    });
//close button
    $(".btn-close").click(function(e){
        $(".navbar-collapse").removeClass("show");
        $("body").removeClass("offcanvas-active");
    })
})


//time
var dt = new Date();
document.getElementById('date-time').innerHTML=dt;